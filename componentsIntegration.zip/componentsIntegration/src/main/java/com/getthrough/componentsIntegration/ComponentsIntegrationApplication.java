package com.getthrough.componentsIntegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComponentsIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComponentsIntegrationApplication.class, args);
	}

}
