package com.getthrough.componentsIntegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponentsIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
